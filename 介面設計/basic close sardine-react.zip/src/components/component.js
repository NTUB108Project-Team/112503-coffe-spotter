import React from 'react'

import { Player } from '@lottiefiles/react-lottie-player'

import './component.css'

const AppComponent = (props) => {
  return (
    <div className="component-container">
      <Player
        src="https://presentation-website-assets.teleporthq.io/features/lottie.json"
        speed="1"
        autoplay
        background="transparent"
        className="component-lottie-node"
      ></Player>
    </div>
  )
}

export default AppComponent
