import React from 'react'

import PropTypes from 'prop-types'

import './list.css'

const List = (props) => {
  return (
    <ul className="list-list list">
      <li className="list-item">
        <span>{props.text}</span>
      </li>
      <li className="list-li1 list-item">
        <span className="list-text1">{props.text1}</span>
      </li>
      <li className="list-li2 list-item">
        <span className="list-text2">{props.text2}</span>
      </li>
    </ul>
  )
}

List.defaultProps = {
  text2: 'Text',
  text1: 'Text',
  text: 'Text',
}

List.propTypes = {
  text2: PropTypes.string,
  text1: PropTypes.string,
  text: PropTypes.string,
}

export default List
